package Modelo;
public interface ObservadorPedido {
    void actualizar(String mensaje);
}