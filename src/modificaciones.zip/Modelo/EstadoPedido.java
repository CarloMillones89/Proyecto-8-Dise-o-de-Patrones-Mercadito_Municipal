package Modelo;
public interface EstadoPedido {
    String getNombreEstado();
}

